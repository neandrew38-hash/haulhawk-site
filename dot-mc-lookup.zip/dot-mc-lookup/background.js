// DOT/MC Lookup - background worker.
// Looks carriers up in the FMCSA Company Census File, the official public register published by the
// US DOT on data.transportation.gov (dataset az4n-8mr2). No account or API key needed.
// Results are cached for 12 hours so the same number is never fetched twice in a row.

const API = 'https://data.transportation.gov/resource/az4n-8mr2.json';
const TTL = 12 * 3600 * 1000;
const cache = new Map();

function whereFor(type, num) {
  const n = String(num).replace(/\D/g, '').replace(/^0+/, '');
  if (!n) return null;
  if (type === 'DOT') return `dot_number='${n}'`;
  const p = type === 'MX' ? 'MX' : type === 'FF' ? 'FF' : 'MC';
  return `(docket1prefix='${p}' AND docket1='${n}') OR (docket2prefix='${p}' AND docket2='${n}') OR (docket3prefix='${p}' AND docket3='${n}')`;
}

async function lookup(type, num) {
  const key = type + ':' + num;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.res;
  const where = whereFor(type, num);
  if (!where) return { ok: false, error: 'Not a valid number' };
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 15000);
  try {
    const r = await fetch(API + '?' + new URLSearchParams({ $where: where, $limit: '3' }), { signal: ctl.signal });
    if (!r.ok) return { ok: false, error: 'FMCSA data is not answering (HTTP ' + r.status + ')' };
    const rows = await r.json();
    const res = rows.length ? { ok: true, rec: rows[0], more: rows.length - 1 } : { ok: true, rec: null };
    cache.set(key, { at: Date.now(), res });
    if (cache.size > 300) cache.delete(cache.keys().next().value);
    return res;
  } catch (e) {
    return { ok: false, error: e.name === 'AbortError' ? 'FMCSA data took too long - try again' : 'No connection to FMCSA data' };
  } finally { clearTimeout(timer); }
}

// Company name search: "Sample Auto Transport" -> up to 8 carriers whose legal or DBA name contains it.
async function searchName(q) {
  const words = String(q || '').toUpperCase().replace(/[^A-Z0-9& ]+/g, ' ').replace(/\b(LLC|INC|CORP|CO|LTD|CORPORATION|COMPANY)\b/g, ' ').trim().split(/\s+/).filter(Boolean).slice(0, 5);
  if (!words.length) return { ok: false, error: 'Select a company name or a number' };
  const cond = f => words.map(w => `upper(${f}) like '%${w.replace(/'/g, "''")}%'`).join(' AND ');
  const where = `(${cond('legal_name')}) OR (${cond('dba_name')})`;
  const key = 'N:' + words.join(' ');
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.res;
  try {
    const r = await fetch(API + '?' + new URLSearchParams({ $where: where, $select: 'dot_number,legal_name,dba_name,phy_city,phy_state,status_code,power_units,docket1prefix,docket1', $order: 'status_code ASC, power_units DESC', $limit: '8' }));
    if (!r.ok) return { ok: false, error: 'FMCSA data is not answering (HTTP ' + r.status + ')' };
    const list = await r.json();
    // exact name (ignoring punctuation and LLC / INC ...) goes to the top; one exact match = open its card directly
    const norm = t => String(t || '').toUpperCase().replace(/[^A-Z0-9& ]+/g, ' ').replace(/\b(LLC|INC|CORP|CO|LTD|CORPORATION|COMPANY)\b/g, ' ').replace(/\s+/g, ' ').trim();
    const want = words.join(' ');
    list.forEach(x => { x.exact = norm(x.legal_name) === want || norm(x.dba_name) === want; });
    list.sort((a, b) => (b.exact - a.exact) || ((a.status_code === 'A' ? 0 : 1) - (b.status_code === 'A' ? 0 : 1)));
    const exact = list.filter(x => x.exact), exactActive = exact.filter(x => x.status_code === 'A');
    const direct = exactActive.length === 1 ? exactActive[0].dot_number : exact.length === 1 ? exact[0].dot_number : list.length === 1 ? list[0].dot_number : null;
    const res = { ok: true, list, direct };
    cache.set(key, { at: Date.now(), res });
    return res;
  } catch (e) { return { ok: false, error: 'No connection to FMCSA data' }; }
}

// ---- Authority, insurance and safety (2026-10-08) - more FMCSA open datasets on data.transportation.gov:
//   6eyk-hxee  Carrier (L&I): operating authority status (common / contract / broker), insurance on file
//   qh9u-swkp  ActPendInsur: active and pending insurance policies (insurer, type, coverage, dates)
//   rbkj-cgst  SMS Input - Inspection: roadside inspections of the last 24 months
//   4wxs-vbns  SMS Input - Crash: reportable crashes of the last 24 months
const RES = 'https://data.transportation.gov/resource/';
async function getJson(id, params) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 20000);
  try {
    const r = await fetch(RES + id + '.json?' + new URLSearchParams(params), { signal: ctl.signal });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}
const MON = { JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4, JUN: 5, JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11 };
function smsDate(s) {   // "03-NOV-24" -> ms
  const m = /^(\d{1,2})-([A-Z]{3})-(\d{2})$/.exec(String(s || '').toUpperCase());
  return m ? Date.UTC(2000 + +m[3], MON[m[2]] || 0, +m[1]) : 0;
}
async function details(dot) {
  const d = String(dot || '').replace(/\D/g, '').replace(/^0+/, '');
  if (!d) return { ok: false, error: 'No USDOT number' };
  const key = 'D:' + d;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.res;
  const pad = d.padStart(8, '0');
  const [car, ins, insp, crash, hist] = await Promise.allSettled([
    getJson('6eyk-hxee', { $where: `dot_number='${pad}'`, $limit: '10' }),
    getJson('qh9u-swkp', { $where: `dot_number='${pad}'`, $limit: '30' }),
    getJson('rbkj-cgst', { $select: 'insp_date,insp_level_id,driver_oos_total,vehicle_oos_total,basic_viol', $where: `dot_number='${d}'`, $limit: '5000' }),
    getJson('4wxs-vbns', { $select: 'report_date,fatalities,injuries,tow_away', $where: `dot_number='${d}'`, $limit: '1000' }),
    // 9mw4-x3tu  AuthHist - All With History: when each authority was granted, revoked, reinstated...
    getJson('9mw4-x3tu', { $where: `dot_number='${pad}'`, $limit: '200' }),
  ]);
  const res = { ok: true };
  if (car.status === 'fulfilled') {
    res.authority = car.value.map(c => ({
      docket: c.docket_number, common: c.common_stat, contract: c.contract_stat, broker: c.broker_stat,
      pending: [c.common_app_pend, c.contract_app_pend, c.broker_app_pend].includes('Y'),
      revoking: [c.common_rev_pend, c.contract_rev_pend, c.broker_rev_pend].includes('Y'),
      property: c.property_chk === 'Y', hhg: c.hhg_chk === 'Y', passenger: c.passenger_chk === 'Y',
      bipdReq: +c.min_cov_amount || 0, bipdOnFile: +c.bipd_file || 0, cargoReq: c.cargo_req === 'Y', cargoOnFile: c.cargo_file === 'Y',
      bondReq: c.bond_req === 'Y', bondOnFile: c.bond_file === 'Y', badMail: c.undeliverable_mail === 'Y',
    }));
  }
  if (ins.status === 'fulfilled') {
    res.insurance = ins.value.map(x => ({ type: x.mod_col_1 || x.ins_form_code || '', insurer: x.name_company || '', policy: x.policy_no || '',
      coverage: +x.max_cov_amount || 0, effective: x.effective_date || '', cancels: x.cancl_effective_date || '', docket: x.docket_number || '' }));
  }
  if (insp.status === 'fulfilled') {
    const rows = insp.value, num = v => Number(v) || 0;
    // driver OOS counts levels 1, 2, 3, 6; vehicle OOS counts levels 1, 2, 5, 6 (FMCSA's own way of computing the rates)
    const dr = rows.filter(r => ['1', '2', '3', '6'].includes(String(r.insp_level_id)));
    const vh = rows.filter(r => ['1', '2', '5', '6'].includes(String(r.insp_level_id)));
    const dates = rows.map(r => smsDate(r.insp_date)).filter(Boolean).sort((a, b) => a - b);
    res.safety = { inspections: rows.length, driverInsp: dr.length, driverOos: dr.filter(r => num(r.driver_oos_total) > 0).length,
      vehicleInsp: vh.length, vehicleOos: vh.filter(r => num(r.vehicle_oos_total) > 0).length,
      violations: rows.reduce((a, r) => a + num(r.basic_viol), 0), first: dates[0] || 0, last: dates[dates.length - 1] || 0 };
  }
  if (crash.status === 'fulfilled') {
    const c = crash.value, num = v => Number(v) || 0;
    res.crashes = { total: c.length, fatal: c.filter(x => num(x.fatalities) > 0).length, injury: c.filter(x => num(x.injuries) > 0).length,
      tow: c.filter(x => /^(true|y)$/i.test(String(x.tow_away))).length };
  }
  if (hist.status === 'fulfilled') {
    res.authHist = hist.value.map(h => ({ docket: h.docket_number || '', type: h.mod_col_1 || '', orig: h.original_action_desc || '',
      origDate: h.orig_served_date || '', disp: h.disp_action_desc || '', dispDate: h.disp_served_date || h.disp_decided_date || '' }));
  }
  if (!res.authority && !res.insurance && !res.safety) return { ok: false, error: 'FMCSA data is not answering - try again' };
  cache.set(key, { at: Date.now(), res });
  return res;
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.kind === 'details') { details(msg.dot).then(reply).catch(() => reply({ ok: false, error: 'No connection to FMCSA data' })); return true; }
  if (msg && msg.kind === 'lookup') { lookup(msg.type, msg.num).then(reply); return true; }
  if (msg && msg.kind === 'search') { searchName(msg.q).then(reply); return true; }
  if (msg && msg.kind === 'clearCache') { cache.clear(); reply({ ok: true }); return false; }
  return false;
});

// Right-click on selected text (a company name or a number) -> "Look up carrier"
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => chrome.contextMenus.create({ id: 'dmc-lookup', title: 'Look up carrier: "%s"', contexts: ['selection'] }));
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== 'dmc-lookup' || !tab || tab.id == null) return;
  chrome.tabs.sendMessage(tab.id, { kind: 'menu', text: info.selectionText || '' }, { frameId: info.frameId || 0 }, () => void chrome.runtime.lastError);
});
