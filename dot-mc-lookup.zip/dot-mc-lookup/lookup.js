// DOT/MC Lookup - shared helpers for the page card and the popup: turn an FMCSA census record into
// a carrier card. Loaded before content.js (content script) and by popup.html.
(function () {
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const title = s => String(s || '').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
  const date = d => (d && d.length === 8 ? `${d.slice(4, 6)}/${d.slice(6, 8)}/${d.slice(0, 4)}` : '');
  const phone = p => { const d = String(p || '').replace(/\D/g, ''); return d.length === 10 ? `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}` : (p || ''); };
  const n = v => Number(v) || 0;

  function ageText(d) {
    if (!d || d.length !== 8) return '';
    const t = new Date(+d.slice(0, 4), +d.slice(4, 6) - 1, +d.slice(6, 8));
    const days = Math.floor((Date.now() - t) / 86400000);
    if (days < 60) return days + ' days';
    if (days < 730) return Math.round(days / 30) + ' months';
    return (days / 365).toFixed(1).replace(/\.0$/, '') + ' years';
  }

  const CARGO = { crgo_genfreight: 'General freight', crgo_motoveh: 'Motor vehicles', crgo_drivetow: 'Driveaway/towaway', crgo_household: 'Household goods',
    crgo_bldgmat: 'Building materials', crgo_machlrg: 'Machinery', crgo_produce: 'Produce', crgo_intermodal: 'Intermodal', crgo_coldfood: 'Refrigerated food',
    crgo_drybulk: 'Dry bulk', crgo_metalsheet: 'Metal', crgo_logpole: 'Logs/lumber', crgo_construct: 'Construction', crgo_beverages: 'Beverages', crgo_paperprod: 'Paper' };

  function snapshotUrl(rec, type, num) {
    if (rec && rec.dot_number) return 'https://safer.fmcsa.dot.gov/query.asp?searchtype=ANY&query_type=queryCarrierSnapshot&query_param=USDOT&query_string=' + rec.dot_number;
    return 'https://safer.fmcsa.dot.gov/query.asp?searchtype=ANY&query_type=queryCarrierSnapshot&query_param=' + (type === 'DOT' ? 'USDOT' : 'MC_MX') + '&query_string=' + encodeURIComponent(num);
  }

  // res = { ok, rec, error } from background.js
  function cardHtml(res, type, num) {
    const label = (type === 'DOT' ? 'USDOT ' : type + '-') + num;
    if (!res) return `<div class="dmc-head"><b>${esc(label)}</b></div><div class="dmc-muted">Looking up…</div>`;
    if (!res.ok) return `<div class="dmc-head"><b>${esc(label)}</b></div><div class="dmc-bad">${esc(res.error)}</div><a class="dmc-link" target="_blank" rel="noopener" href="${snapshotUrl(null, type, num)}">Open in FMCSA SAFER ↗</a>`;
    const r = res.rec;
    if (!r) return `<div class="dmc-head"><b>${esc(label)}</b></div><div class="dmc-muted">Not found in the FMCSA register. New carriers can take a few days to appear.</div><a class="dmc-link" target="_blank" rel="noopener" href="${snapshotUrl(null, type, num)}">Check FMCSA SAFER ↗</a>`;
    const active = r.status_code === 'A';
    const mc = r.docket1prefix && r.docket1 ? `${r.docket1prefix}-${r.docket1}` : '';
    const auth = r.docket1_status_code === 'A' ? 'Active' : r.docket1_status_code ? 'Not active' : '';
    const cargo = Object.keys(CARGO).filter(k => r[k] === 'X').map(k => CARGO[k]);
    if (r.crgo_cargoothr_desc) cargo.push(title(r.crgo_cargoothr_desc));
    const tractors = n(r.owntract) + n(r.trmtract) + n(r.trptract), trailers = n(r.owntrail) + n(r.trmtrail) + n(r.trptrail);
    const rows = [
      ['USDOT', r.dot_number + (mc ? ` · ${mc}` : '')],
      ['Type', [r.classdef ? title(r.classdef) : '', r.carrier_operation === 'A' ? 'Interstate' : r.carrier_operation === 'B' || r.carrier_operation === 'C' ? 'Intrastate' : ''].filter(Boolean).join(' · ')],
      mc ? ['Authority', auth] : null,
      ['Fleet', `${n(r.power_units)} power unit${n(r.power_units) === 1 ? '' : 's'}` + (tractors ? ` · ${tractors} tractor${tractors === 1 ? '' : 's'}` : '') + (trailers ? ` · ${trailers} trailer${trailers === 1 ? '' : 's'}` : '') + ` · ${n(r.total_drivers)} driver${n(r.total_drivers) === 1 ? '' : 's'}`],
      cargo.length ? ['Cargo', cargo.slice(0, 6).join(', ')] : null,
      ['Contact', [title(r.company_officer_1), r.phone ? `<span class="dmc-copy" data-copy="${esc(r.phone)}" title="Copy">${esc(phone(r.phone))}</span>` : '', r.email_address ? `<span class="dmc-copy" data-copy="${esc(String(r.email_address).toLowerCase())}" title="Copy">${esc(String(r.email_address).toLowerCase())}</span>` : ''].filter(Boolean).join('<br>')],
      ['Address', [title(r.phy_street), [title(r.phy_city), r.phy_state, r.phy_zip].filter(Boolean).join(', ')].filter(Boolean).map(esc).join('<br>')],
      ['Registered', date(r.add_date) + (r.add_date ? ` <span class="dmc-muted">(${ageText(r.add_date)})</span>` : '')],
      r.mcs150_date ? ['MCS-150', date(r.mcs150_date)] : null,
      r.safety_rating ? ['Safety', { S: 'Satisfactory', C: 'Conditional', U: 'Unsatisfactory' }[r.safety_rating] || r.safety_rating] : null,
    ].filter(row => row && String(row[1] || '').replace(/<[^>]*>/g, '').trim());
    return `<div class="dmc-head"><b>${esc(r.legal_name || label)}</b><span class="dmc-pill ${active ? 'dmc-ok' : 'dmc-off'}">${active ? 'Active' : 'Inactive'}</span></div>`
      + (r.dba_name ? `<div class="dmc-muted">DBA ${esc(r.dba_name)}</div>` : '')
      + `<div class="dmc-flagslot"></div>`
      + `<table class="dmc-t">${rows.map(([k, v]) => `<tr><td>${k}</td><td>${k === 'Contact' || k === 'Address' || k === 'Registered' ? v : esc(v)}</td></tr>`).join('')}</table>`
      + `<div class="dmc-more" data-dot="${esc(r.dot_number)}"><div class="dmc-muted" style="padding:8px 0 2px">Checking authority, insurance and safety…</div></div>`
      + `<div class="dmc-links"><button class="dmc-btn" data-copysum="1">Copy summary</button><a class="dmc-link" target="_blank" rel="noopener" href="${snapshotUrl(r)}">SAFER snapshot ↗</a><a class="dmc-link" target="_blank" rel="noopener" href="https://ai.fmcsa.dot.gov/SMS/Carrier/${r.dot_number}/CarrierRegistration.aspx">Safety (SMS) ↗</a></div>`
      + `<div class="dmc-src">FMCSA public register · data.transportation.gov</div>`;
  }

  function wireCopy(root) {
    root.querySelectorAll('.dmc-copy').forEach(el => el.addEventListener('click', e => {
      e.stopPropagation();
      navigator.clipboard.writeText(el.dataset.copy).then(() => { const t = el.textContent; el.textContent = 'Copied ✓'; setTimeout(() => { el.textContent = t; }, 900); }).catch(() => {});
    }));
  }

  const CARD_CSS = `
    .dmc-card{font:13px/1.45 -apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:#1d1f24;background:#fff;border:1px solid #e3e5ea;border-radius:12px;
      box-shadow:0 10px 30px rgba(0,0,0,.18);padding:12px 14px;width:360px;max-width:calc(100vw - 24px);box-sizing:border-box}
    .dmc-head{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;font-size:14.5px;margin-bottom:2px}
    .dmc-head b{font-weight:700;line-height:1.3}
    .dmc-pill{font-size:11px;font-weight:700;padding:2px 8px;border-radius:999px;white-space:nowrap}
    .dmc-ok{background:#e3f6ea;color:#1c7c45}.dmc-off{background:#fde8e8;color:#b42318}
    .dmc-muted{color:#6b7280;font-size:12px}.dmc-bad{color:#b42318;margin:4px 0 6px}
    .dmc-t{width:100%;border-collapse:collapse;margin-top:8px}
    .dmc-t td{padding:4px 0;vertical-align:top;border-top:1px solid #f0f1f4;overflow-wrap:anywhere}
    .dmc-t td:first-child{color:#6b7280;width:86px;padding-right:8px;font-size:12px}
    .dmc-copy{cursor:pointer;border-bottom:1px dashed #b9bdc6}.dmc-copy:hover{color:#de7752}
    .dmc-links{display:flex;gap:12px;margin-top:10px;flex-wrap:wrap}
    .dmc-link{color:#c45d39;font-weight:600;text-decoration:none}.dmc-link:hover{text-decoration:underline}
    .dmc-src{color:#9aa0aa;font-size:10.5px;margin-top:8px}
    .dmc-flags{display:flex;flex-wrap:wrap;gap:5px;margin:8px 0 2px}
    .dmc-flag{font-size:11.5px;font-weight:600;padding:3px 8px;border-radius:7px;line-height:1.3}
    .dmc-fbad{background:#fde8e8;color:#b42318}.dmc-fwarn{background:#fff3dc;color:#8a5300}.dmc-fgood{background:#e3f6ea;color:#1c7c45}
    .dmc-sec{font-size:10.5px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:#9aa0aa;margin:12px 0 2px}
    .dmc-okt{color:#1c7c45}.dmc-badt{color:#b42318}
    .dmc-boxes{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:6px}
    .dmc-box{border:1px solid #eceef2;border-radius:9px;padding:7px 9px;display:flex;flex-direction:column}
    .dmc-box b{font-size:16px}.dmc-box span{font-size:11.5px;color:#6b7280}.dmc-box i{font-style:normal;font-size:10.5px;color:#9aa0aa}
    .dmc-boxbad{border-color:#f3b4b4;background:#fff6f6}
    .dmc-btn{font:inherit;font-size:12px;font-weight:700;border:1px solid #e3e5ea;background:#f6f7f9;color:#1d1f24;border-radius:8px;padding:3px 9px;cursor:pointer}
    .dmc-btn:hover{border-color:#de7752}
    .dmc-row{padding:8px 0;border-top:1px solid #f0f1f4;cursor:pointer}.dmc-row:hover b{color:#de7752}
    .dmc-x{position:absolute;top:6px;right:8px;border:0;background:none;font-size:16px;color:#9aa0aa;cursor:pointer;line-height:1}
    @media (prefers-color-scheme: dark){
      .dmc-card{background:#1b1e24;color:#e8eaee;border-color:#2c313b}
      .dmc-t td,.dmc-row{border-top-color:#272b33}.dmc-muted,.dmc-t td:first-child{color:#9aa0aa}
      .dmc-ok{background:#173a26;color:#6fdc9a}.dmc-off{background:#3d1d1d;color:#ff9b9b}
      .dmc-link{color:#f0946f}
      .dmc-fbad{background:#3d1d1d;color:#ff9b9b}.dmc-fwarn{background:#3a2c12;color:#ffcc7a}.dmc-fgood{background:#173a26;color:#6fdc9a}
      .dmc-box{border-color:#2c313b}.dmc-boxbad{border-color:#6b2a2a;background:#2a1717}.dmc-okt{color:#6fdc9a}.dmc-badt{color:#ff9b9b}
      .dmc-btn{background:#23272f;border-color:#2c313b;color:#e8eaee}
    }`;

  // ---- authority, insurance and safety (filled in after the main card) ----
  const US_DRIVER_OOS = 6.7, US_VEHICLE_OOS = 22.3;   // approximate US averages FMCSA shows on SAFER
  const money = k => k ? '$' + (k * 1000).toLocaleString('en-US') : '';
  const pct = (a, b) => b ? Math.round(a / b * 1000) / 10 : null;
  const STAT = v => v === 'A' ? 'Active' : v === 'I' ? 'Inactive' : '';
  function usDate(s) { const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(String(s || '')); return m ? new Date(+m[3], +m[1] - 1, +m[2]) : null; }
  function flagsOf(rec, det) {
    const f = [];
    if (rec.status_code !== 'A') f.push(['bad', 'USDOT inactive']);
    const auth = (det.authority || [])[0];
    const forHire = /FOR HIRE/i.test(rec.classdef || '') || (det.authority || []).length;
    const anyActive = (det.authority || []).some(a => a.common === 'A' || a.contract === 'A' || a.broker === 'A');
    if (forHire && det.authority && !anyActive) f.push(['bad', 'No active operating authority']);
    if ((det.authority || []).some(a => a.revoking)) f.push(['bad', 'Revocation pending']);
    if ((det.authority || []).some(a => a.pending)) f.push(['warn', 'Authority application pending']);
    const bipd = (det.insurance || []).filter(i => /BIPD/i.test(i.type));
    const bipdActive = bipd.filter(i => { const c = usDate(i.cancels); return !c || c > new Date(); });
    if (anyActive && auth && auth.bipdReq && !auth.bipdOnFile && !bipdActive.length) f.push(['bad', 'No liability insurance on file']);
    if (bipd.some(i => { const c = usDate(i.cancels); return c && c > new Date() && c - new Date() < 45 * 864e5; })) f.push(['warn', 'Insurance cancels soon']);
    if (rec.add_date && rec.add_date.length === 8) {
      const days = Math.floor((Date.now() - new Date(+rec.add_date.slice(0, 4), +rec.add_date.slice(4, 6) - 1, +rec.add_date.slice(6, 8))) / 864e5);
      if (days < 180) f.push(['warn', `New carrier - registered ${days} days ago`]);
    }
    const sf = det.safety;
    if (sf && sf.vehicleInsp >= 5 && pct(sf.vehicleOos, sf.vehicleInsp) > US_VEHICLE_OOS * 1.5) f.push(['warn', 'High vehicle out-of-service rate']);
    if (sf && sf.driverInsp >= 5 && pct(sf.driverOos, sf.driverInsp) > US_DRIVER_OOS * 1.5) f.push(['warn', 'High driver out-of-service rate']);
    if (det.crashes && det.crashes.fatal) f.push(['warn', `${det.crashes.fatal} fatal crash${det.crashes.fatal > 1 ? 'es' : ''} in 24 months`]);
    if ((det.authority || []).some(a => a.badMail)) f.push(['warn', 'Mail to their address comes back']);
    return f;
  }
  function detailsHtml(det, rec) {
    if (!det) return '<div class="dmc-muted" style="padding:8px 0 2px">Checking authority, insurance and safety…</div>';
    if (!det.ok) return `<div class="dmc-muted" style="padding:8px 0 2px">${esc(det.error || 'Could not load safety data')}</div>`;
    let h = '';
    // authority
    const auths = det.authority || [];
    if (auths.length) {
      h += '<div class="dmc-sec">Operating authority</div><table class="dmc-t">' + auths.map(a => {
        const kinds = [['Carrier', a.common], ['Contract', a.contract], ['Broker', a.broker]].filter(([, v]) => v === 'A' || v === 'I').map(([k, v]) => `${k}: <b class="${v === 'A' ? 'dmc-okt' : 'dmc-badt'}">${STAT(v)}</b>`).join(' · ') || 'None';
        const what = [a.property ? 'Property' : '', a.hhg ? 'Household goods' : '', a.passenger ? 'Passengers' : ''].filter(Boolean).join(', ');
        return `<tr><td>${esc(a.docket)}</td><td>${kinds}${what ? `<br><span class="dmc-muted">${esc(what)}</span>` : ''}${a.pending ? '<br><span class="dmc-muted">Application pending</span>' : ''}</td></tr>`;
      }).join('') + '</table>';
    }
    // insurance
    const ins = (det.insurance || []).slice().sort((x, y) => (/BIPD/i.test(y.type) - /BIPD/i.test(x.type)));
    h += '<div class="dmc-sec">Insurance on file with FMCSA</div>';
    if (ins.length) {
      h += '<table class="dmc-t">' + ins.slice(0, 6).map(i => {
        const c = usDate(i.cancels), cancelled = c && c <= new Date();
        return `<tr><td>${esc(i.type.replace('/Primary', '').replace('BIPD', 'Liability (BIPD)') || 'Policy')}</td><td>${esc(i.insurer)}${i.coverage ? ' · ' + money(i.coverage) : ''}<br><span class="dmc-muted">since ${esc(i.effective)}${i.cancels ? ` · <span class="${cancelled ? '' : 'dmc-badt'}">${cancelled ? 'cancelled' : 'cancels'} ${esc(i.cancels)}</span>` : ''}</span></td></tr>`;
      }).join('') + '</table>';
    } else h += '<div class="dmc-muted">No policies filed. Ask for a certificate of insurance (COI).</div>';
    const a0 = auths[0];
    if (a0 && !a0.cargoOnFile) h += '<div class="dmc-muted" style="font-size:11px;margin-top:2px">Cargo insurance is usually not filed with FMCSA - check it on their COI.</div>';
    // safety
    const sf = det.safety, cr = det.crashes;
    h += '<div class="dmc-sec">Safety - last 24 months</div>';
    if (sf && sf.inspections) {
      const dp = pct(sf.driverOos, sf.driverInsp), vp = pct(sf.vehicleOos, sf.vehicleInsp);
      const box = (val, label, sub, bad) => `<div class="dmc-box${bad ? ' dmc-boxbad' : ''}"><b>${val}</b><span>${label}</span>${sub ? `<i>${sub}</i>` : ''}</div>`;
      h += '<div class="dmc-boxes">'
        + box(sf.inspections, 'Inspections', `${sf.violations} violations`)
        + box(vp == null ? '–' : vp + '%', 'Vehicle OOS', `US avg ≈ ${US_VEHICLE_OOS}%`, vp > US_VEHICLE_OOS * 1.5 && sf.vehicleInsp >= 5)
        + box(dp == null ? '–' : dp + '%', 'Driver OOS', `US avg ≈ ${US_DRIVER_OOS}%`, dp > US_DRIVER_OOS * 1.5 && sf.driverInsp >= 5)
        + box(cr ? cr.total : '–', 'Crashes', cr && cr.total ? [cr.fatal ? cr.fatal + ' fatal' : '', cr.injury ? cr.injury + ' injury' : '', cr.tow ? cr.tow + ' tow' : ''].filter(Boolean).join(' · ') : 'none', cr && cr.fatal)
        + '</div>';
    } else h += `<div class="dmc-muted">No roadside inspections in the last 24 months${cr && cr.total ? ` · ${cr.total} crash${cr.total > 1 ? 'es' : ''}` : ''}.</div>`;
    return h;
  }
  function flagsHtml(det, rec) {
    if (!det || !det.ok) return '';
    const flags = flagsOf(rec, det);
    return '<div class="dmc-flags">' + (flags.length ? flags.map(([k, t]) => `<span class="dmc-flag dmc-f${k}">${k === 'bad' ? '⛔' : '⚠️'} ${esc(t)}</span>`).join('') : '<span class="dmc-flag dmc-fgood">✓ No red flags found</span>') + '</div>';
  }
  function summaryText(rec, det) {
    const r = rec || {}, d = det || {};
    const mc = r.docket1prefix && r.docket1 ? `${r.docket1prefix}-${r.docket1}` : '';
    const bipd = (d.insurance || []).find(i => /BIPD/i.test(i.type));
    const flags = d.ok ? flagsOf(r, d).map(x => x[1]) : [];
    return [`${r.legal_name || ''}${r.dba_name ? ' (DBA ' + r.dba_name + ')' : ''}`,
      `USDOT ${r.dot_number}${mc ? ' · ' + mc : ''} · ${r.status_code === 'A' ? 'Active' : 'Inactive'}`,
      [title(r.phy_city), r.phy_state].filter(Boolean).join(', '),
      r.phone ? 'Phone: ' + phone(r.phone) : '', r.email_address ? 'Email: ' + String(r.email_address).toLowerCase() : '',
      `Fleet: ${n(r.power_units)} power units, ${n(r.total_drivers)} drivers`,
      bipd ? `Liability insurance: ${bipd.insurer} ${money(bipd.coverage)}` : '',
      d.safety && d.safety.inspections ? `Inspections (24 mo): ${d.safety.inspections}, vehicle OOS ${pct(d.safety.vehicleOos, d.safety.vehicleInsp) || 0}%, driver OOS ${pct(d.safety.driverOos, d.safety.driverInsp) || 0}%` : '',
      flags.length ? 'Flags: ' + flags.join('; ') : '',
      'Source: FMCSA public data'].filter(Boolean).join('\n');
  }
  // the page card and the popup both call this after painting the main card
  function wireDetails(root, rec, ask) {
    const box = root.querySelector('.dmc-more');
    const btn = root.querySelector('[data-copysum]');
    let det = null;
    if (btn) btn.addEventListener('click', e => { e.stopPropagation(); navigator.clipboard.writeText(summaryText(rec, det)).then(() => { btn.textContent = 'Copied ✓'; setTimeout(() => { btn.textContent = 'Copy summary'; }, 1200); }).catch(() => {}); });
    if (!box || !rec) return;
    ask(rec.dot_number, res => { det = res; box.innerHTML = detailsHtml(res, rec); const fs = root.querySelector('.dmc-flagslot'); if (fs) fs.innerHTML = flagsHtml(res, rec); });
  }

  // results of a company-name search: a short list, each row opens its card
  function listHtml(res, q) {
    if (!res) return `<div class="dmc-head"><b>"${esc(q)}"</b></div><div class="dmc-muted">Searching the FMCSA register…</div>`;
    if (!res.ok) return `<div class="dmc-head"><b>"${esc(q)}"</b></div><div class="dmc-bad">${esc(res.error)}</div>`;
    if (!res.list.length) return `<div class="dmc-head"><b>"${esc(q)}"</b></div><div class="dmc-muted">No carrier with that name in the FMCSA register.</div>`;
    return `<div class="dmc-head"><b>Carriers matching "${esc(q)}"</b></div>` + res.list.map(r =>
      `<div class="dmc-row" data-dot="${esc(r.dot_number)}"><b>${esc(r.legal_name)}</b>${r.exact ? ' <span class="dmc-pill dmc-ok">Exact name</span>' : ''}${r.status_code === 'A' ? '' : ' <span class="dmc-pill dmc-off">Inactive</span>'}<br><span class="dmc-muted">${esc(title(r.phy_city))}, ${esc(r.phy_state || '')} · USDOT ${esc(r.dot_number)}${r.docket1prefix ? ' · ' + esc(r.docket1prefix + '-' + r.docket1) : ''} · ${n(r.power_units)} truck${n(r.power_units) === 1 ? '' : 's'}</span></div>`).join('');
  }
  // what the user selected: a number (with or without DOT / MC) or a name
  function parseSel(t) {
    t = String(t || '').trim();
    let m = /^(?:U\.?S\.?\s*)?DOT\s*[#:-]?\s*(\d{4,8})$/i.exec(t); if (m) return { type: 'DOT', num: m[1] };
    m = /^(MC|MX|FF)\s*[#:-]?\s*(\d{3,8})$/i.exec(t); if (m) return { type: m[1].toUpperCase(), num: m[2] };
    m = /^#?\s*(\d{4,8})$/.exec(t); if (m) return { type: 'DOT', num: m[1] };
    return t.length >= 3 && t.length <= 80 ? { name: t } : null;
  }

  self.DMC = { cardHtml, wireCopy, CARD_CSS, listHtml, parseSel, wireDetails, detailsHtml };
})();
