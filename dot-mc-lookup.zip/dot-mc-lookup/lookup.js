// DOT/MC Lookup - shared helpers for the page card and the popup: turn an FMCSA census record into
// a carrier card. Loaded before content.js (content script) and by popup.html.
(function () {
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const title = s => String(s || '').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
  const date = d => (d && d.length === 8 ? `${d.slice(4, 6)}/${d.slice(6, 8)}/${d.slice(0, 4)}` : '');
  const phone = p => { const d = String(p || '').replace(/\D/g, ''); return d.length === 10 ? `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}` : (p || ''); };
  const n = v => Number(v) || 0;

  function ageText(d) {
    if (!d || d.length !== 8) return '';
    const t = new Date(+d.slice(0, 4), +d.slice(4, 6) - 1, +d.slice(6, 8));
    const days = Math.floor((Date.now() - t) / 86400000);
    if (days < 60) return days + ' days';
    if (days < 730) return Math.round(days / 30) + ' months';
    return (days / 365).toFixed(1).replace(/\.0$/, '') + ' years';
  }

  const CARGO = { crgo_genfreight: 'General freight', crgo_motoveh: 'Motor vehicles', crgo_drivetow: 'Driveaway/towaway', crgo_household: 'Household goods',
    crgo_bldgmat: 'Building materials', crgo_machlrg: 'Machinery', crgo_produce: 'Produce', crgo_intermodal: 'Intermodal', crgo_coldfood: 'Refrigerated food',
    crgo_drybulk: 'Dry bulk', crgo_metalsheet: 'Metal', crgo_logpole: 'Logs/lumber', crgo_construct: 'Construction', crgo_beverages: 'Beverages', crgo_paperprod: 'Paper' };

  function snapshotUrl(rec, type, num) {
    if (rec && rec.dot_number) return 'https://safer.fmcsa.dot.gov/query.asp?searchtype=ANY&query_type=queryCarrierSnapshot&query_param=USDOT&query_string=' + rec.dot_number;
    return 'https://safer.fmcsa.dot.gov/query.asp?searchtype=ANY&query_type=queryCarrierSnapshot&query_param=' + (type === 'DOT' ? 'USDOT' : 'MC_MX') + '&query_string=' + encodeURIComponent(num);
  }

  // res = { ok, rec, error } from background.js
  function cardHtml(res, type, num) {
    const label = (type === 'DOT' ? 'USDOT ' : type + '-') + num;
    if (!res) return `<div class="dmc-head"><b>${esc(label)}</b></div><div class="dmc-muted">Looking up…</div>`;
    if (!res.ok) return `<div class="dmc-head"><b>${esc(label)}</b></div><div class="dmc-bad">${esc(res.error)}</div><a class="dmc-link" target="_blank" rel="noopener" href="${snapshotUrl(null, type, num)}">Open in FMCSA SAFER ↗</a>`;
    const r = res.rec;
    if (!r) return `<div class="dmc-head"><b>${esc(label)}</b></div><div class="dmc-muted">Not found in the FMCSA register. New carriers can take a few days to appear.</div><a class="dmc-link" target="_blank" rel="noopener" href="${snapshotUrl(null, type, num)}">Check FMCSA SAFER ↗</a>`;
    const active = r.status_code === 'A';
    const mc = r.docket1prefix && r.docket1 ? `${r.docket1prefix}-${r.docket1}` : '';
    const auth = r.docket1_status_code === 'A' ? 'Active' : r.docket1_status_code ? 'Not active' : '';
    const cargo = Object.keys(CARGO).filter(k => r[k] === 'X').map(k => CARGO[k]);
    if (r.crgo_cargoothr_desc) cargo.push(title(r.crgo_cargoothr_desc));
    const tractors = n(r.owntract) + n(r.trmtract) + n(r.trptract), trailers = n(r.owntrail) + n(r.trmtrail) + n(r.trptrail);
    const rows = [
      ['USDOT', r.dot_number + (mc ? ` · ${mc}` : '')],
      ['Type', [r.classdef ? title(r.classdef) : '', r.carrier_operation === 'A' ? 'Interstate' : r.carrier_operation === 'B' || r.carrier_operation === 'C' ? 'Intrastate' : ''].filter(Boolean).join(' · ')],
      mc ? ['Authority', auth] : null,
      ['Fleet', `${n(r.power_units)} power unit${n(r.power_units) === 1 ? '' : 's'}` + (tractors ? ` · ${tractors} tractor${tractors === 1 ? '' : 's'}` : '') + (trailers ? ` · ${trailers} trailer${trailers === 1 ? '' : 's'}` : '') + ` · ${n(r.total_drivers)} driver${n(r.total_drivers) === 1 ? '' : 's'}`],
      cargo.length ? ['Cargo', cargo.slice(0, 6).join(', ')] : null,
      ['Contact', [title(r.company_officer_1), r.phone ? `<span class="dmc-copy" data-copy="${esc(r.phone)}" title="Copy">${esc(phone(r.phone))}</span>` : '', r.email_address ? `<span class="dmc-copy" data-copy="${esc(String(r.email_address).toLowerCase())}" title="Copy">${esc(String(r.email_address).toLowerCase())}</span>` : ''].filter(Boolean).join('<br>')],
      ['Address', [title(r.phy_street), [title(r.phy_city), r.phy_state, r.phy_zip].filter(Boolean).join(', ')].filter(Boolean).map(esc).join('<br>')],
      ['Registered', date(r.add_date) + (r.add_date ? ` <span class="dmc-muted">(${ageText(r.add_date)})</span>` : '')],
      r.mcs150_date ? ['MCS-150', date(r.mcs150_date)] : null,
      r.safety_rating ? ['Safety', { S: 'Satisfactory', C: 'Conditional', U: 'Unsatisfactory' }[r.safety_rating] || r.safety_rating] : null,
    ].filter(Boolean);
    return `<div class="dmc-head"><b>${esc(r.legal_name || label)}</b><span class="dmc-pill ${active ? 'dmc-ok' : 'dmc-off'}">${active ? 'Active' : 'Inactive'}</span></div>`
      + (r.dba_name ? `<div class="dmc-muted">DBA ${esc(r.dba_name)}</div>` : '')
      + `<table class="dmc-t">${rows.map(([k, v]) => `<tr><td>${k}</td><td>${k === 'Contact' || k === 'Address' || k === 'Registered' ? v : esc(v)}</td></tr>`).join('')}</table>`
      + `<div class="dmc-links"><a class="dmc-link" target="_blank" rel="noopener" href="${snapshotUrl(r)}">SAFER snapshot ↗</a><a class="dmc-link" target="_blank" rel="noopener" href="https://ai.fmcsa.dot.gov/SMS/Carrier/${r.dot_number}/CarrierRegistration.aspx">Safety (SMS) ↗</a></div>`
      + `<div class="dmc-src">FMCSA public register · data.transportation.gov</div>`;
  }

  function wireCopy(root) {
    root.querySelectorAll('.dmc-copy').forEach(el => el.addEventListener('click', e => {
      e.stopPropagation();
      navigator.clipboard.writeText(el.dataset.copy).then(() => { const t = el.textContent; el.textContent = 'Copied ✓'; setTimeout(() => { el.textContent = t; }, 900); }).catch(() => {});
    }));
  }

  const CARD_CSS = `
    .dmc-card{font:13px/1.45 -apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:#1d1f24;background:#fff;border:1px solid #e3e5ea;border-radius:12px;
      box-shadow:0 10px 30px rgba(0,0,0,.18);padding:12px 14px;width:320px;max-width:calc(100vw - 24px);box-sizing:border-box}
    .dmc-head{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;font-size:14.5px;margin-bottom:2px}
    .dmc-head b{font-weight:700;line-height:1.3}
    .dmc-pill{font-size:11px;font-weight:700;padding:2px 8px;border-radius:999px;white-space:nowrap}
    .dmc-ok{background:#e3f6ea;color:#1c7c45}.dmc-off{background:#fde8e8;color:#b42318}
    .dmc-muted{color:#6b7280;font-size:12px}.dmc-bad{color:#b42318;margin:4px 0 6px}
    .dmc-t{width:100%;border-collapse:collapse;margin-top:8px}
    .dmc-t td{padding:4px 0;vertical-align:top;border-top:1px solid #f0f1f4;overflow-wrap:anywhere}
    .dmc-t td:first-child{color:#6b7280;width:86px;padding-right:8px;font-size:12px}
    .dmc-copy{cursor:pointer;border-bottom:1px dashed #b9bdc6}.dmc-copy:hover{color:#de7752}
    .dmc-links{display:flex;gap:12px;margin-top:10px;flex-wrap:wrap}
    .dmc-link{color:#c45d39;font-weight:600;text-decoration:none}.dmc-link:hover{text-decoration:underline}
    .dmc-src{color:#9aa0aa;font-size:10.5px;margin-top:8px}
    .dmc-row{padding:8px 0;border-top:1px solid #f0f1f4;cursor:pointer}.dmc-row:hover b{color:#de7752}
    .dmc-x{position:absolute;top:6px;right:8px;border:0;background:none;font-size:16px;color:#9aa0aa;cursor:pointer;line-height:1}
    @media (prefers-color-scheme: dark){
      .dmc-card{background:#1b1e24;color:#e8eaee;border-color:#2c313b}
      .dmc-t td,.dmc-row{border-top-color:#272b33}.dmc-muted,.dmc-t td:first-child{color:#9aa0aa}
      .dmc-ok{background:#173a26;color:#6fdc9a}.dmc-off{background:#3d1d1d;color:#ff9b9b}
      .dmc-link{color:#f0946f}
    }`;

  // results of a company-name search: a short list, each row opens its card
  function listHtml(res, q) {
    if (!res) return `<div class="dmc-head"><b>"${esc(q)}"</b></div><div class="dmc-muted">Searching the FMCSA register…</div>`;
    if (!res.ok) return `<div class="dmc-head"><b>"${esc(q)}"</b></div><div class="dmc-bad">${esc(res.error)}</div>`;
    if (!res.list.length) return `<div class="dmc-head"><b>"${esc(q)}"</b></div><div class="dmc-muted">No carrier with that name in the FMCSA register.</div>`;
    return `<div class="dmc-head"><b>Carriers matching "${esc(q)}"</b></div>` + res.list.map(r =>
      `<div class="dmc-row" data-dot="${esc(r.dot_number)}"><b>${esc(r.legal_name)}</b>${r.status_code === 'A' ? '' : ' <span class="dmc-pill dmc-off">Inactive</span>'}<br><span class="dmc-muted">${esc(title(r.phy_city))}, ${esc(r.phy_state || '')} · USDOT ${esc(r.dot_number)}${r.docket1prefix ? ' · ' + esc(r.docket1prefix + '-' + r.docket1) : ''} · ${n(r.power_units)} truck${n(r.power_units) === 1 ? '' : 's'}</span></div>`).join('');
  }
  // what the user selected: a number (with or without DOT / MC) or a name
  function parseSel(t) {
    t = String(t || '').trim();
    let m = /^(?:U\.?S\.?\s*)?DOT\s*[#:-]?\s*(\d{4,8})$/i.exec(t); if (m) return { type: 'DOT', num: m[1] };
    m = /^(MC|MX|FF)\s*[#:-]?\s*(\d{3,8})$/i.exec(t); if (m) return { type: m[1].toUpperCase(), num: m[2] };
    m = /^#?\s*(\d{4,8})$/.exec(t); if (m) return { type: 'DOT', num: m[1] };
    return t.length >= 3 && t.length <= 80 ? { name: t } : null;
  }

  self.DMC = { cardHtml, wireCopy, CARD_CSS, listHtml, parseSel };
})();
