// DOT/MC Lookup - content script. Finds USDOT / MC numbers in the page text, underlines them, and shows
// the carrier card when one is clicked. The card lives in a Shadow DOM so the page's styles can't break it.
(function () {
  if (window.__dmcLoaded) return;
  window.__dmcLoaded = true;

  // "USDOT 1234567", "US DOT# 1234567", "DOT: 1234567", "DOT No. 1234567"
  const DOT_RE = /\b(?:U\.?\s?S\.?\s?)?DOT\s*(?:#|No\.?|Number|:)?\s*[:#]?\s*(\d{5,8})\b/gi;
  // "MC-123456", "MC# 123456", "MC 123456", "MC Number: 123456" (also MX / FF dockets)
  const MC_RE = /\b(MC|MX|FF)\s*(?:#|-|No\.?|Number|:)?\s*[:#-]?\s*(\d{4,7})\b/g;
  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT', 'SELECT', 'OPTION', 'CODE', 'PRE', 'SVG', 'CANVAS', 'IFRAME']);
  let enabled = true;

  function findAll(text) {
    const hits = [];
    let m;
    DOT_RE.lastIndex = 0;
    while ((m = DOT_RE.exec(text))) hits.push({ start: m.index, end: m.index + m[0].length, type: 'DOT', num: m[1] });
    MC_RE.lastIndex = 0;
    while ((m = MC_RE.exec(text))) {
      if (hits.some(h => m.index < h.end && m.index + m[0].length > h.start)) continue;
      hits.push({ start: m.index, end: m.index + m[0].length, type: m[1].toUpperCase(), num: m[2] });
    }
    return hits.sort((a, b) => a.start - b.start);
  }

  // Label and number in DIFFERENT elements - "MC #" in one tag and "123456" in the next, "DOT" in one table
  // cell and the number in the next, or "MC Number" as a column header with the numbers below (Central
  // Dispatch and most load boards lay profiles out like that).
  const LABEL_RE = /(?:^|[^A-Za-z])(U\.?\s?S\.?\s?DOT|DOT|MC|MX|FF)\s*(?:#|No\.?|Number|Num\.?)?\s*[:#-]?\s*$/i;
  const ONLY_NUM = /^\s*#?\s*(\d{4,8})\s*$/;
  const typeOf = m => (/DOT/i.test(m[1]) ? 'DOT' : m[1].toUpperCase());
  function labelBefore(node) {
    let t = '';
    for (let s = node.previousSibling; s && t.length < 40; s = s.previousSibling) t = (s.textContent || '') + t;
    let m = LABEL_RE.exec(t.trim());
    if (m) return m;
    let el = node.parentElement;
    for (let i = 0; i < 4 && el && el !== document.body; i++, el = el.parentElement) {
      // a table cell: the cell before it, or its column's header
      if (el.tagName === 'TD' || el.tagName === 'TH') {
        const prev = el.previousElementSibling;
        if (prev && (m = LABEL_RE.exec((prev.textContent || '').trim()))) return m;
        const table = el.closest('table'), idx = el.cellIndex;
        const head = table && (table.tHead ? table.tHead.rows[0] : table.rows[0]);
        if (head && head !== el.parentElement && head.cells[idx] && (m = LABEL_RE.exec((head.cells[idx].textContent || '').trim()))) return m;
        return null;
      }
      const prev = el.previousElementSibling;
      if (prev) {
        const pt = (prev.textContent || '').trim();
        if (pt.length <= 40 && (m = LABEL_RE.exec(pt))) return m;
        if (pt) return null;   // something else stands before it - not a label
      }
    }
    return null;
  }

  // Highlighting WITHOUT touching the page: the matches are kept as Range objects and painted with the
  // browser's CSS Custom Highlight API (::highlight(dmc-hit) in content.css). The page's own DOM is never
  // changed, so React apps like Central Dispatch can't break and the page can't see anything was added.
  let hits = [];   // { range, type, num }
  const HL = typeof Highlight === 'function' && window.CSS && CSS.highlights ? new Highlight() : null;
  if (HL) CSS.highlights.set('dmc-hit', HL);

  function addHit(node, start, end, type, num) {
    const r = document.createRange();
    r.setStart(node, start); r.setEnd(node, end);
    hits.push({ range: r, type, num });
    if (HL) HL.add(r);
  }

  function scan() {
    if (!enabled || !document.body) return;
    hits = [];
    if (HL) HL.clear();
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const p = node.parentElement;
        if (!p || SKIP.has(p.tagName) || p.closest('#dmc-host')) return NodeFilter.FILTER_REJECT;
        const v = node.nodeValue;
        return /\d{4}/.test(v) && (/DOT|MC|MX|FF/i.test(v) || ONLY_NUM.test(v)) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      },
    });
    let count = 0;
    while (walker.nextNode() && count < 3000) {
      const node = walker.currentNode; count++;
      const text = node.nodeValue;
      const found = findAll(text);
      if (found.length) { found.forEach(h => addHit(node, h.start, h.end, h.type, h.num)); continue; }
      const n = ONLY_NUM.exec(text);
      const lab = n && labelBefore(node);
      if (!lab) continue;
      const type = typeOf(lab);
      if (type === 'DOT' && n[1].length < 5) continue;
      const st = text.indexOf(n[1]);
      addHit(node, st, st + n[1].length, type, n[1]);
    }
  }

  // which highlighted number is under the mouse
  function hitAt(x, y) {
    let node = null, offset = 0;
    if (document.caretPositionFromPoint) { const c = document.caretPositionFromPoint(x, y); if (c) { node = c.offsetNode; offset = c.offset; } }
    else if (document.caretRangeFromPoint) { const c = document.caretRangeFromPoint(x, y); if (c) { node = c.startContainer; offset = c.startOffset; } }
    if (!node || node.nodeType !== 3) return null;
    for (const h of hits) {
      if (h.range.startContainer !== node) continue;
      if (offset >= h.range.startOffset && offset <= h.range.endOffset) {
        const r = h.range.getBoundingClientRect();
        if (x >= r.left - 2 && x <= r.right + 2 && y >= r.top - 2 && y <= r.bottom + 2) return h;
      }
    }
    return null;
  }

  // ---- the floating card ----
  let host = null, shadow = null, shownFor = null;
  function closeCard() { if (host) host.style.display = 'none'; shownFor = null; }
  function place(rect) {
    if (!host) {
      host = document.createElement('div');
      host.id = 'dmc-host';
      host.style.cssText = 'position:absolute;z-index:2147483647;top:0;left:0;display:none';
      shadow = host.attachShadow({ mode: 'open' });
      document.documentElement.appendChild(host);
      host.addEventListener('mouseenter', () => clearTimeout(hideTimer));
      host.addEventListener('mouseleave', () => { if (hoverOpened) hideSoon(); });
    }
    const left = Math.max(8, Math.min(window.scrollX + rect.left, window.scrollX + document.documentElement.clientWidth - 376));
    host.style.left = left + 'px';
    host.style.top = (window.scrollY + rect.bottom + 6) + 'px';
    host.style.display = 'block';
  }
  function paint(html) {
    shadow.innerHTML = `<style>${self.DMC.CARD_CSS}.dmc-head{padding-right:16px}</style><div class="dmc-card" style="position:relative;max-height:min(78vh,680px);overflow:auto"><button class="dmc-x" title="Close">×</button>${html}</div>`;
    shadow.querySelector('.dmc-x').onclick = closeCard;
    self.DMC.wireCopy(shadow);
  }
  // Phone numbers written right next to the USDOT / MC on the page (same line, row or block) - compared
  // with the FMCSA record to catch a "carrier" whose contact number isn't theirs.
  const PHONE_RE = /(?:\+?1[\s.-]?)?\(?\b(\d{3})\)?[\s.-]?(\d{3})[\s.-](\d{4})\b/g;
  function phonesNear(range) {
    let el = range && range.startContainer && range.startContainer.parentElement;
    for (let i = 0; i < 6 && el && el !== document.body; i++, el = el.parentElement) {
      const t = el.innerText || el.textContent || '';
      if (t.length > 700) break;   // went past this company's own block
      const out = []; let m;
      PHONE_RE.lastIndex = 0;
      while ((m = PHONE_RE.exec(t))) out.push(m[1] + m[2] + m[3]);
      if (out.length) return Array.from(new Set(out)).slice(0, 4);
    }
    return [];
  }

  function showNumber(rect, type, num, ctx) {
    place(rect);
    const key = type + num; shownFor = key;
    paint(self.DMC.cardHtml(null, type, num));
    chrome.runtime.sendMessage({ kind: 'lookup', type, num }, res => {
      if (chrome.runtime.lastError) res = { ok: false, error: 'The extension was updated - reload this page' };
      if (shownFor !== key) return;
      paint(self.DMC.cardHtml(res, type, num));
      if (res && res.ok && res.rec) self.DMC.wireDetails(shadow, res.rec, (dot, cb) => chrome.runtime.sendMessage({ kind: 'details', dot }, d => { if (chrome.runtime.lastError) d = { ok: false, error: 'Could not load safety data' }; if (shownFor === key) cb(d); }), ctx);
    });
  }
  function showName(rect, q) {
    place(rect);
    const key = 'N' + q; shownFor = key;
    paint(self.DMC.listHtml(null, q));
    chrome.runtime.sendMessage({ kind: 'search', q }, res => {
      if (chrome.runtime.lastError) res = { ok: false, error: 'The extension was updated - reload this page' };
      if (shownFor !== key) return;
      if (res && res.ok && res.direct) { showNumber(rect, 'DOT', res.direct); return; }
      paint(self.DMC.listHtml(res, q));
      shadow.querySelectorAll('.dmc-row').forEach(row => row.addEventListener('click', ev => { ev.stopPropagation(); hoverOpened = false; showNumber(rect, 'DOT', row.dataset.dot); }));
    });
  }
  const openCard = h => showNumber(h.range.getBoundingClientRect(), h.type, h.num, { pagePhones: phonesNear(h.range) });

  // Hover over a highlighted number for a moment -> the card opens (and closes when the mouse leaves).
  // A click opens it too and keeps it open. Inside a link: hover works, click opens the link as usual.
  let hoverTimer = null, hideTimer = null, hoverOpened = false, lastMove = 0;
  const typing = () => !!(shadow && shadow.activeElement && shadow.activeElement.tagName === 'TEXTAREA');
  function hideSoon() { clearTimeout(hideTimer); hideTimer = setTimeout(() => { if (hoverOpened && !typing()) closeCard(); }, 500); }
  // throttled to ~16 checks a second, but the LAST position is always checked (a mouse that stops on a
  // number must open the card even if its final move came right after a check)
  let pendingMove = null, moveTimer = null;
  document.addEventListener('mousemove', e => {
    if (!hits.length && !e.altKey) return;
    if (host && e.composedPath().includes(host)) { clearTimeout(hideTimer); return; }
    pendingMove = { x: e.clientX, y: e.clientY, alt: e.altKey };
    const wait = 60 - (Date.now() - lastMove);
    if (wait <= 0) onMove(); else if (!moveTimer) moveTimer = setTimeout(onMove, wait);
  }, { passive: true });
  function onMove() {
    moveTimer = null; lastMove = Date.now();
    if (!pendingMove) return;
    const { x, y, alt } = pendingMove; pendingMove = null;
    const h = hitAt(x, y);
    // Alt (Option on Mac) + hover over a company name -> look it up by name
    if (!h && alt) {
      const el = document.elementFromPoint(x, y);
      const t = el && !el.closest('#dmc-host') ? (el.innerText || el.textContent || '').trim() : '';
      clearTimeout(hoverTimer);
      if (t && t.length >= 3 && t.length <= 80 && !/\n/.test(t) && shownFor !== 'N' + t) {
        const rect = el.getBoundingClientRect();
        hoverTimer = setTimeout(() => { hoverOpened = true; const p = self.DMC.parseSel(t); if (p && p.name) showName(rect, p.name); else if (p) showNumber(rect, p.type, p.num); }, 350);
      }
      return;
    }
    if (!!h !== document.documentElement.classList.contains('dmc-pointer')) document.documentElement.classList.toggle('dmc-pointer', !!h);
    clearTimeout(hoverTimer);
    if (h) {
      clearTimeout(hideTimer);
      if (shownFor === h.type + h.num) return;
      hoverTimer = setTimeout(() => { hoverOpened = true; openCard(h); }, 350);
    } else if (hoverOpened && shownFor) hideSoon();
  }

  document.addEventListener('click', e => {
    if (host && e.composedPath().includes(host)) return;
    const h = enabled && hits.length ? hitAt(e.clientX, e.clientY) : null;
    if (h) {
      const inLink = h.range.startContainer.parentElement && h.range.startContainer.parentElement.closest('a[href], button');
      if (!inLink || e.altKey) { e.preventDefault(); e.stopPropagation(); clearTimeout(hoverTimer); hoverOpened = false; if (shownFor !== h.type + h.num) openCard(h); return; }
    }
    closeCard();
  }, true);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeCard(); });

  // right-click menu "Look up carrier" on selected text, and the popup asking how many numbers were found
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (msg && msg.kind === 'count') { reply({ count: hits.length, enabled }); return; }
    if (!msg || msg.kind !== 'menu') return;
    const sel = window.getSelection();
    let rect = sel && sel.rangeCount ? sel.getRangeAt(0).getBoundingClientRect() : null;
    if (!rect || (!rect.width && !rect.height)) rect = { left: 40, bottom: 40 };
    const p = self.DMC.parseSel(msg.text);
    hoverOpened = false;
    if (!p) return;
    if (p.name) showName(rect, p.name); else showNumber(rect, p.type, p.num);
  });

  // pages that load content later (load boards, web mail): look again at most once a second after changes
  let timer = null;
  const mo = new MutationObserver(list => {
    if (list.every(m => m.target === host || (host && host.contains(m.target)))) return;
    if (!timer) timer = setTimeout(() => { timer = null; scan(); }, 1000);
  });

  chrome.storage.local.get({ highlight: true }, s => {
    enabled = s.highlight !== false;
    if (!enabled) return;
    scan();
    mo.observe(document.body, { childList: true, subtree: true, characterData: true });
  });
})();
