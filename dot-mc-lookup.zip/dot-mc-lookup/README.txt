DOT/MC Lookup - Chrome extension (also Edge, Brave, Opera)
============================================================

What it does
- Underlines USDOT and MC numbers on any web page (load boards, broker emails, rate confirmations).
- Hover over one (or click it): a card with the carrier's FMCSA profile - name, active/inactive, trucks and
  trailers, drivers, cargo types, phone and email (click to copy), address, how long they've been registered.
- Red flags at the top: no liability insurance on file, inactive / new / pending authority, revocation
  pending, high out-of-service rates, fatal crashes.
- Operating authority (carrier / contract / broker), insurance filings (insurer, coverage, dates) and a
  24-month safety summary (inspections, vehicle and driver OOS rates vs the US average, crashes).
- "Copy summary" copies all of it as text.
- New in 2.1:
  * Phone check: if the page shows a phone next to the USDOT / MC that is not on the FMCSA record, the card
    warns you and shows the official number to call instead.
  * Young authority: "Authority granted N days ago" (under 6 months) or "Authority under 1 year", with the
    grant date shown next to each MC in the Operating authority section.
  * Recent changes: authority revoked / reinstated in the last 12 months, company details (MCS-150) updated
    in the last 90 days, and name, phone, email or address that changed since you last looked them up.
  * Team notes: mark a carrier or broker "Worked with", "Caution" or "Avoid" and add a short note. It shows
    at the top of the card next time. Notes stay in your browser - use Export / Import in the toolbar popup
    to share them with your team.
- Company names: hold Alt (Option on a Mac) and hover over the name - or select it -> right-click ->
  "Look up carrier". An exact name match opens its card straight away; otherwise you get a short list.
- The toolbar button has a search box: type "3466676", "MC 1133377" or a company name. It also shows
  how many USDOT / MC numbers it found on the open page.
- "Highlight on pages" switch turns the underlining off if you only want the search box.

Where the data comes from
- FMCSA open data published by the US DOT on data.transportation.gov: Company Census File, Carrier and
  ActPendInsur (licensing & insurance), AuthHist (authority history), SMS Input - Inspection and Crash. No account, no API key,
  nothing is sent anywhere else.
- The register is refreshed regularly, but a brand-new carrier can take a few days to appear.

Install (until it is in the Chrome Web Store)
1. Unzip the folder somewhere it can stay.
2. Open chrome://extensions and switch on "Developer mode" (top right).
3. Click "Load unpacked" and choose the "dot-mc-lookup" folder.
4. Pin the orange magnifier icon to the toolbar.
