DOT/MC Lookup - Chrome extension (also Edge, Brave, Opera)
============================================================

What it does
- Underlines USDOT and MC numbers on any web page (load boards, broker emails, rate confirmations).
- Hover over one (or click it): a card with the carrier's FMCSA profile - name, active/inactive, authority, trucks and
  trailers, drivers, cargo types, phone and email (click to copy), address, how long they've been registered,
  links to SAFER and the FMCSA safety page.
- Company names: hold Alt (Option on a Mac) and hover over the name - or select it -> right-click ->
  "Look up carrier". An exact name match opens its card straight away; otherwise you get a short list.
- The toolbar button has a search box: type "3466676", "MC 1133377" or a company name. It also shows
  how many USDOT / MC numbers it found on the open page.
- "Highlight on pages" switch turns the underlining off if you only want the search box.

Where the data comes from
- FMCSA Company Census File - the official public carrier register published by the US DOT on
  data.transportation.gov. No account, no API key, nothing is sent anywhere else.
- The register is refreshed regularly, but a brand-new carrier can take a few days to appear.

Install (until it is in the Chrome Web Store)
1. Unzip the folder somewhere it can stay.
2. Open chrome://extensions and switch on "Developer mode" (top right).
3. Click "Load unpacked" and choose the "dot-mc-lookup" folder.
4. Pin the orange magnifier icon to the toolbar.
