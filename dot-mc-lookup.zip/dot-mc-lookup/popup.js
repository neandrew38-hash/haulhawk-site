// DOT/MC Lookup - toolbar popup: search box, the highlight switch and the last few lookups.
document.getElementById('cardcss').textContent = self.DMC.CARD_CSS;
const out = document.getElementById('out'), q = document.getElementById('q'), hl = document.getElementById('hl');

// (kept for reference; the search box now uses DMC.parseSel, which also accepts company names)
function parse(s) {
  s = String(s || '').trim().toUpperCase();
  const m = /^(MC|MX|FF)\s*[-#:]?\s*(\d{3,8})$/.exec(s);
  if (m) return { type: m[1], num: m[2] };
  const d = /^(?:US\s*)?(?:DOT)?\s*[-#:]?\s*(\d{3,8})$/.exec(s);
  if (d) return { type: 'DOT', num: d[1] };
  return null;
}

function show(type, num) {
  document.getElementById('hint').style.display = 'none';
  out.innerHTML = '<div class="dmc-card">' + self.DMC.cardHtml(null, type, num) + '</div>';
  chrome.runtime.sendMessage({ kind: 'lookup', type, num }, res => {
    out.innerHTML = '<div class="dmc-card">' + self.DMC.cardHtml(res, type, num) + '</div>';
    if (res && res.ok && res.rec) self.DMC.wireDetails(out, res.rec, (dot, cb) => chrome.runtime.sendMessage({ kind: 'details', dot }, cb));
    self.DMC.wireCopy(out);
    if (res && res.ok && res.rec) remember(type, num, res.rec.legal_name);
  });
}

function remember(type, num, name) {
  chrome.storage.local.get({ recent: [] }, s => {
    const list = [{ type, num, name }].concat(s.recent.filter(x => !(x.type === type && x.num === num))).slice(0, 6);
    chrome.storage.local.set({ recent: list }, drawRecent);
  });
}
function drawRecent() {
  chrome.storage.local.get({ recent: [] }, s => {
    const box = document.getElementById('recent');
    box.innerHTML = '';
    document.getElementById('recentHead').style.display = s.recent.length ? 'flex' : 'none';
    s.recent.forEach(x => {
      const b = document.createElement('button');
      b.textContent = (x.name ? x.name.slice(0, 22) : '') + ' · ' + (x.type === 'DOT' ? 'DOT ' : x.type + ' ') + x.num;
      b.onclick = () => { q.value = (x.type === 'DOT' ? '' : x.type + ' ') + x.num; show(x.type, x.num); };
      box.appendChild(b);
    });
  });
}

function showName(q) {
  document.getElementById('hint').style.display = 'none';
  out.innerHTML = '<div class="dmc-card">' + self.DMC.listHtml(null, q) + '</div>';
  chrome.runtime.sendMessage({ kind: 'search', q }, res => {
    if (res && res.ok && res.direct) { show('DOT', res.direct); return; }
    out.innerHTML = '<div class="dmc-card">' + self.DMC.listHtml(res, q) + '</div>';
    out.querySelectorAll('.dmc-row').forEach(r => r.addEventListener('click', () => show('DOT', r.dataset.dot)));
  });
}

document.getElementById('f').addEventListener('submit', e => {
  e.preventDefault();
  const p = self.DMC.parseSel(q.value);
  if (!p) { out.innerHTML = '<div class="dmc-card"><div class="dmc-bad">Type a USDOT / MC number or a company name.</div></div>'; return; }
  if (p.name) showName(p.name); else show(p.type, p.num);
});

// how many USDOT / MC numbers the extension found on the open tab
chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
  const t = tabs && tabs[0], hint = document.getElementById('hint');
  if (!t || t.id == null) return;
  chrome.tabs.sendMessage(t.id, { kind: 'count' }, res => {
    if (chrome.runtime.lastError || !res) { hint.innerHTML = 'Not active on this tab yet - <b>reload the page</b> (needed once after installing or updating).'; return; }
    hint.innerHTML = !res.enabled ? 'Highlighting is off. Search here, or select text on the page → right-click → <b>Look up carrier</b>.'
      : res.count ? `Found <b>${res.count}</b> USDOT / MC number${res.count === 1 ? '' : 's'} on this page - hover over one.`
      : 'No USDOT / MC numbers found on this page. Select a company name or number → right-click → <b>Look up carrier</b>.';
  });
});

chrome.storage.local.get({ highlight: true }, s => { hl.checked = s.highlight !== false; });
hl.addEventListener('change', () => chrome.storage.local.set({ highlight: hl.checked }));
drawRecent();
// "Clear" next to the recent lookups: forget them (and the cached answers in the background worker)
document.getElementById('clearRecent').addEventListener('click', () => {
  chrome.storage.local.set({ recent: [] }, drawRecent);
  chrome.runtime.sendMessage({ kind: 'clearCache' }, () => void chrome.runtime.lastError);
});

// ---- team notes: export to a file for teammates, import theirs (newer note wins) ----
function drawNotesCount() {
  chrome.storage.local.get({ notes: {} }, s => {
    const n = Object.keys(s.notes).length;
    document.getElementById('notesCount').textContent = n ? `Team notes: ${n} compan${n === 1 ? 'y' : 'ies'}` : 'Team notes: none yet';
  });
}
document.getElementById('exportNotes').addEventListener('click', () => {
  chrome.storage.local.get({ notes: {} }, s => {
    const blob = new Blob([JSON.stringify({ app: 'dot-mc-lookup', kind: 'notes', exported: new Date().toISOString(), notes: s.notes }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'dot-mc-team-notes-' + new Date().toISOString().slice(0, 10) + '.json';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  });
});
document.getElementById('importNotes').addEventListener('change', e => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  file.text().then(txt => {
    let data;
    try { data = JSON.parse(txt); } catch (err) { data = null; }
    const incoming = data && data.notes && typeof data.notes === 'object' ? data.notes : null;
    if (!incoming) { document.getElementById('notesCount').textContent = 'Not a DOT/MC notes file'; return; }
    chrome.storage.local.get({ notes: {} }, s => {
      let added = 0;
      Object.keys(incoming).forEach(dot => {
        const x = incoming[dot];
        if (!/^\d{1,8}$/.test(dot) || !x || typeof x !== 'object') return;
        const clean = { tag: ['good', 'caution', 'avoid'].includes(x.tag) ? x.tag : '', text: String(x.text || '').slice(0, 500),
          name: String(x.name || '').slice(0, 120), mc: String(x.mc || '').slice(0, 20), at: Number(x.at) || Date.now() };
        if (!clean.tag && !clean.text) return;
        if (!s.notes[dot] || (s.notes[dot].at || 0) < clean.at) { s.notes[dot] = clean; added++; }
      });
      chrome.storage.local.set({ notes: s.notes }, () => {
        drawNotesCount();
        setTimeout(() => { document.getElementById('notesCount').textContent = `Imported ${added} note${added === 1 ? '' : 's'}`; }, 50);
        setTimeout(drawNotesCount, 2500);
      });
    });
  });
  e.target.value = '';
});
drawNotesCount();
