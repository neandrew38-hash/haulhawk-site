// DOT/MC Lookup - background worker.
// Looks carriers up in the FMCSA Company Census File, the official public register published by the
// US DOT on data.transportation.gov (dataset az4n-8mr2). No account or API key needed.
// Results are cached for 12 hours so the same number is never fetched twice in a row.

const API = 'https://data.transportation.gov/resource/az4n-8mr2.json';
const TTL = 12 * 3600 * 1000;
const cache = new Map();

function whereFor(type, num) {
  const n = String(num).replace(/\D/g, '').replace(/^0+/, '');
  if (!n) return null;
  if (type === 'DOT') return `dot_number='${n}'`;
  const p = type === 'MX' ? 'MX' : type === 'FF' ? 'FF' : 'MC';
  return `(docket1prefix='${p}' AND docket1='${n}') OR (docket2prefix='${p}' AND docket2='${n}') OR (docket3prefix='${p}' AND docket3='${n}')`;
}

async function lookup(type, num) {
  const key = type + ':' + num;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.res;
  const where = whereFor(type, num);
  if (!where) return { ok: false, error: 'Not a valid number' };
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 15000);
  try {
    const r = await fetch(API + '?' + new URLSearchParams({ $where: where, $limit: '3' }), { signal: ctl.signal });
    if (!r.ok) return { ok: false, error: 'FMCSA data is not answering (HTTP ' + r.status + ')' };
    const rows = await r.json();
    const res = rows.length ? { ok: true, rec: rows[0], more: rows.length - 1 } : { ok: true, rec: null };
    cache.set(key, { at: Date.now(), res });
    if (cache.size > 300) cache.delete(cache.keys().next().value);
    return res;
  } catch (e) {
    return { ok: false, error: e.name === 'AbortError' ? 'FMCSA data took too long - try again' : 'No connection to FMCSA data' };
  } finally { clearTimeout(timer); }
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.kind === 'lookup') { lookup(msg.type, msg.num).then(reply); return true; }
  return false;
});
