// DOT/MC Lookup - content script. Finds USDOT / MC numbers in the page text, underlines them, and shows
// the carrier card when one is clicked. The card lives in a Shadow DOM so the page's styles can't break it.
(function () {
  if (window.__dmcLoaded) return;
  window.__dmcLoaded = true;

  // "USDOT 1234567", "US DOT# 1234567", "DOT: 1234567", "DOT No. 1234567"
  const DOT_RE = /\b(?:U\.?\s?S\.?\s?)?DOT\s*(?:#|No\.?|Number|:)?\s*[:#]?\s*(\d{5,8})\b/gi;
  // "MC-123456", "MC# 123456", "MC 123456", "MC Number: 123456" (also MX / FF dockets)
  const MC_RE = /\b(MC|MX|FF)\s*(?:#|-|No\.?|Number|:)?\s*[:#-]?\s*(\d{4,7})\b/g;
  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT', 'SELECT', 'OPTION', 'CODE', 'PRE', 'SVG', 'CANVAS', 'IFRAME']);
  let enabled = true;

  function findAll(text) {
    const hits = [];
    let m;
    DOT_RE.lastIndex = 0;
    while ((m = DOT_RE.exec(text))) hits.push({ start: m.index, end: m.index + m[0].length, type: 'DOT', num: m[1] });
    MC_RE.lastIndex = 0;
    while ((m = MC_RE.exec(text))) {
      if (hits.some(h => m.index < h.end && m.index + m[0].length > h.start)) continue;
      hits.push({ start: m.index, end: m.index + m[0].length, type: m[1].toUpperCase(), num: m[2] });
    }
    return hits.sort((a, b) => a.start - b.start);
  }

  function scan(root) {
    if (!enabled || !root) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const p = node.parentElement;
        if (!p || SKIP.has(p.tagName) || p.isContentEditable || p.closest('.dmc-hl, #dmc-host')) return NodeFilter.FILTER_REJECT;
        return /\d{4}/.test(node.nodeValue) && /DOT|MC|MX|FF/i.test(node.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      },
    });
    const nodes = [];
    while (walker.nextNode() && nodes.length < 500) nodes.push(walker.currentNode);
    for (const node of nodes) {
      const text = node.nodeValue;
      const hits = findAll(text);
      if (!hits.length) continue;
      const frag = document.createDocumentFragment();
      let pos = 0;
      for (const h of hits) {
        if (h.start > pos) frag.appendChild(document.createTextNode(text.slice(pos, h.start)));
        const span = document.createElement('span');
        span.className = 'dmc-hl';
        span.dataset.type = h.type;
        span.dataset.num = h.num;
        span.title = 'DOT/MC Lookup - click for the carrier profile';
        span.textContent = text.slice(h.start, h.end);
        frag.appendChild(span);
        pos = h.end;
      }
      if (pos < text.length) frag.appendChild(document.createTextNode(text.slice(pos)));
      node.parentNode.replaceChild(frag, node);
    }
  }

  // ---- the floating card ----
  let host = null, shadow = null;
  function closeCard() { if (host) host.style.display = 'none'; }
  function openCard(el) {
    if (!host) {
      host = document.createElement('div');
      host.id = 'dmc-host';
      host.style.cssText = 'position:absolute;z-index:2147483647;top:0;left:0;display:none';
      shadow = host.attachShadow({ mode: 'open' });
      document.documentElement.appendChild(host);
    }
    const type = el.dataset.type, num = el.dataset.num;
    const r = el.getBoundingClientRect();
    const left = Math.max(8, Math.min(window.scrollX + r.left, window.scrollX + document.documentElement.clientWidth - 336));
    host.style.left = left + 'px';
    host.style.top = (window.scrollY + r.bottom + 6) + 'px';
    host.style.display = 'block';
    const paint = res => {
      shadow.innerHTML = `<style>${self.DMC.CARD_CSS}.dmc-head{padding-right:16px}</style><div class="dmc-card" style="position:relative"><button class="dmc-x" title="Close">×</button>${self.DMC.cardHtml(res, type, num)}</div>`;
      shadow.querySelector('.dmc-x').onclick = closeCard;
      self.DMC.wireCopy(shadow);
    };
    paint(null);
    chrome.runtime.sendMessage({ kind: 'lookup', type, num }, res => {
      if (chrome.runtime.lastError) res = { ok: false, error: 'Extension was updated - reload this page' };
      if (host.style.display !== 'none') paint(res);
    });
  }

  document.addEventListener('click', e => {
    const el = e.target.closest && e.target.closest('.dmc-hl');
    if (el) { e.preventDefault(); e.stopPropagation(); openCard(el); return; }
    if (host && !e.composedPath().includes(host)) closeCard();
  }, true);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeCard(); });

  // pages that load content later (load boards, web mail): rescan what was added, at most twice a second
  let pending = [], timer = null;
  const mo = new MutationObserver(list => {
    for (const m of list) for (const n of m.addedNodes) if (n.nodeType === 1 && n.id !== 'dmc-host' && !(n.classList && n.classList.contains('dmc-hl'))) pending.push(n);
    if (!timer && pending.length) timer = setTimeout(() => { const p = pending; pending = []; timer = null; p.forEach(scan); }, 500);
  });

  chrome.storage.local.get({ highlight: true }, s => {
    enabled = s.highlight !== false;
    if (!enabled) return;
    scan(document.body);
    mo.observe(document.body, { childList: true, subtree: true });
  });
})();
