// DOT/MC Lookup - toolbar popup: search box, the highlight switch and the last few lookups.
document.getElementById('cardcss').textContent = self.DMC.CARD_CSS;
const out = document.getElementById('out'), q = document.getElementById('q'), hl = document.getElementById('hl');

// "1133377" or "DOT 3466676" -> USDOT; "MC 1133377", "MC-1133377", "mx123" -> docket
function parse(s) {
  s = String(s || '').trim().toUpperCase();
  const m = /^(MC|MX|FF)\s*[-#:]?\s*(\d{3,8})$/.exec(s);
  if (m) return { type: m[1], num: m[2] };
  const d = /^(?:US\s*)?(?:DOT)?\s*[-#:]?\s*(\d{3,8})$/.exec(s);
  if (d) return { type: 'DOT', num: d[1] };
  return null;
}

function show(type, num) {
  document.getElementById('hint').style.display = 'none';
  out.innerHTML = '<div class="dmc-card">' + self.DMC.cardHtml(null, type, num) + '</div>';
  chrome.runtime.sendMessage({ kind: 'lookup', type, num }, res => {
    out.innerHTML = '<div class="dmc-card">' + self.DMC.cardHtml(res, type, num) + '</div>';
    self.DMC.wireCopy(out);
    if (res && res.ok && res.rec) remember(type, num, res.rec.legal_name);
  });
}

function remember(type, num, name) {
  chrome.storage.local.get({ recent: [] }, s => {
    const list = [{ type, num, name }].concat(s.recent.filter(x => !(x.type === type && x.num === num))).slice(0, 6);
    chrome.storage.local.set({ recent: list }, drawRecent);
  });
}
function drawRecent() {
  chrome.storage.local.get({ recent: [] }, s => {
    const box = document.getElementById('recent');
    box.innerHTML = '';
    s.recent.forEach(x => {
      const b = document.createElement('button');
      b.textContent = (x.name ? x.name.slice(0, 22) : '') + ' · ' + (x.type === 'DOT' ? 'DOT ' : x.type + ' ') + x.num;
      b.onclick = () => { q.value = (x.type === 'DOT' ? '' : x.type + ' ') + x.num; show(x.type, x.num); };
      box.appendChild(b);
    });
  });
}

document.getElementById('f').addEventListener('submit', e => {
  e.preventDefault();
  const p = parse(q.value);
  if (!p) { out.innerHTML = '<div class="dmc-card"><div class="dmc-bad">Type a USDOT number (digits) or MC / MX / FF and the number.</div></div>'; return; }
  show(p.type, p.num);
});

chrome.storage.local.get({ highlight: true }, s => { hl.checked = s.highlight !== false; });
hl.addEventListener('change', () => chrome.storage.local.set({ highlight: hl.checked }));
drawRecent();
