// DOT/MC Lookup - background worker.
// Looks carriers up in the FMCSA Company Census File, the official public register published by the
// US DOT on data.transportation.gov (dataset az4n-8mr2). No account or API key needed.
// Results are cached for 12 hours so the same number is never fetched twice in a row.

const API = 'https://data.transportation.gov/resource/az4n-8mr2.json';
const TTL = 12 * 3600 * 1000;
const cache = new Map();

function whereFor(type, num) {
  const n = String(num).replace(/\D/g, '').replace(/^0+/, '');
  if (!n) return null;
  if (type === 'DOT') return `dot_number='${n}'`;
  const p = type === 'MX' ? 'MX' : type === 'FF' ? 'FF' : 'MC';
  return `(docket1prefix='${p}' AND docket1='${n}') OR (docket2prefix='${p}' AND docket2='${n}') OR (docket3prefix='${p}' AND docket3='${n}')`;
}

async function lookup(type, num) {
  const key = type + ':' + num;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.res;
  const where = whereFor(type, num);
  if (!where) return { ok: false, error: 'Not a valid number' };
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 15000);
  try {
    const r = await fetch(API + '?' + new URLSearchParams({ $where: where, $limit: '3' }), { signal: ctl.signal });
    if (!r.ok) return { ok: false, error: 'FMCSA data is not answering (HTTP ' + r.status + ')' };
    const rows = await r.json();
    const res = rows.length ? { ok: true, rec: rows[0], more: rows.length - 1 } : { ok: true, rec: null };
    cache.set(key, { at: Date.now(), res });
    if (cache.size > 300) cache.delete(cache.keys().next().value);
    return res;
  } catch (e) {
    return { ok: false, error: e.name === 'AbortError' ? 'FMCSA data took too long - try again' : 'No connection to FMCSA data' };
  } finally { clearTimeout(timer); }
}

// Company name search: "Sample Auto Transport" -> up to 8 carriers whose legal or DBA name contains it.
async function searchName(q) {
  const words = String(q || '').toUpperCase().replace(/[^A-Z0-9& ]+/g, ' ').replace(/\b(LLC|INC|CORP|CO|LTD|CORPORATION|COMPANY)\b/g, ' ').trim().split(/\s+/).filter(Boolean).slice(0, 5);
  if (!words.length) return { ok: false, error: 'Select a company name or a number' };
  const cond = f => words.map(w => `upper(${f}) like '%${w.replace(/'/g, "''")}%'`).join(' AND ');
  const where = `(${cond('legal_name')}) OR (${cond('dba_name')})`;
  const key = 'N:' + words.join(' ');
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.res;
  try {
    const r = await fetch(API + '?' + new URLSearchParams({ $where: where, $select: 'dot_number,legal_name,dba_name,phy_city,phy_state,status_code,power_units,docket1prefix,docket1', $order: 'status_code ASC, power_units DESC', $limit: '8' }));
    if (!r.ok) return { ok: false, error: 'FMCSA data is not answering (HTTP ' + r.status + ')' };
    const list = await r.json();
    // exact name (ignoring punctuation and LLC / INC ...) goes to the top; one exact match = open its card directly
    const norm = t => String(t || '').toUpperCase().replace(/[^A-Z0-9& ]+/g, ' ').replace(/\b(LLC|INC|CORP|CO|LTD|CORPORATION|COMPANY)\b/g, ' ').replace(/\s+/g, ' ').trim();
    const want = words.join(' ');
    list.forEach(x => { x.exact = norm(x.legal_name) === want || norm(x.dba_name) === want; });
    list.sort((a, b) => (b.exact - a.exact) || ((a.status_code === 'A' ? 0 : 1) - (b.status_code === 'A' ? 0 : 1)));
    const exact = list.filter(x => x.exact), exactActive = exact.filter(x => x.status_code === 'A');
    const direct = exactActive.length === 1 ? exactActive[0].dot_number : exact.length === 1 ? exact[0].dot_number : list.length === 1 ? list[0].dot_number : null;
    const res = { ok: true, list, direct };
    cache.set(key, { at: Date.now(), res });
    return res;
  } catch (e) { return { ok: false, error: 'No connection to FMCSA data' }; }
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.kind === 'lookup') { lookup(msg.type, msg.num).then(reply); return true; }
  if (msg && msg.kind === 'search') { searchName(msg.q).then(reply); return true; }
  if (msg && msg.kind === 'clearCache') { cache.clear(); reply({ ok: true }); return false; }
  return false;
});

// Right-click on selected text (a company name or a number) -> "Look up carrier"
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => chrome.contextMenus.create({ id: 'dmc-lookup', title: 'Look up carrier: "%s"', contexts: ['selection'] }));
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== 'dmc-lookup' || !tab || tab.id == null) return;
  chrome.tabs.sendMessage(tab.id, { kind: 'menu', text: info.selectionText || '' }, { frameId: info.frameId || 0 }, () => void chrome.runtime.lastError);
});
